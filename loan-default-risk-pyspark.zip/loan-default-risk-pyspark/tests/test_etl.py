
from pyspark.sql import SparkSession
from src.etl import etl

def test_etl_not_null_dti():
    spark = SparkSession.builder.master("local[1]").appName("t").getOrCreate()
    df = spark.createDataFrame(
        [(1000, None), (2000, 5.0)],
        ["loan_amount", "dti"]
    )
    out = etl(df)
    assert out.where(out.dti.isNull()).count() == 0
    spark.stop()
