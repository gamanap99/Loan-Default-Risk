
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, when
from pyspark.ml.feature import StringIndexer, OneHotEncoder, VectorAssembler

NUMERIC = ["loan_amount", "interest_rate", "term_months", "income", "credit_score", "dti"]
CATEG = ["purpose", "state"]

def build_pipeline(spark):
    indexers = [StringIndexer(inputCol=c, outputCol=f"{c}_idx", handleInvalid="keep") for c in CATEG]
    encoders = [OneHotEncoder(inputCols=[f"{c}_idx"], outputCols=[f"{c}_oh"]) for c in CATEG]

    assembler = VectorAssembler(
        inputCols=NUMERIC + [f"{c}_oh" for c in CATEG],
        outputCol="features"
    )
    return indexers, encoders, assembler

def etl(df):
    # Basic cleaning
    df = df.withColumn("dti", when(col("dti").isNull(), 0.0).otherwise(col("dti")))
    return df
