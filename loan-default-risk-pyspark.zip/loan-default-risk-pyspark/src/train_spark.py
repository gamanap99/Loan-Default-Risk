
import argparse, os
from pyspark.sql import SparkSession
from pyspark.ml.classification import LogisticRegression
from pyspark.ml import Pipeline
from pyspark.ml.evaluation import BinaryClassificationEvaluator
from src.etl import build_pipeline, etl

def main(args):
    spark = SparkSession.builder.appName("loan-default-risk").getOrCreate()

    df = spark.read.csv(args.input, header=True, inferSchema=True)
    df = etl(df)

    indexers, encoders, assembler = build_pipeline(spark)
    lr = LogisticRegression(featuresCol="features", labelCol="defaulted", maxIter=50)

    pipeline = Pipeline(stages=indexers + encoders + [assembler, lr])
    train, test = df.randomSplit([0.8, 0.2], seed=42)

    model = pipeline.fit(train)
    pred = model.transform(test)

    auc = BinaryClassificationEvaluator(labelCol="defaulted").evaluate(pred)
    print(f"AUC: {auc:.4f}")

    model.write().overwrite().save(args.output)
    spark.stop()

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True)
    parser.add_argument("--output", default="artifacts/model")
    main(parser.parse_args())
